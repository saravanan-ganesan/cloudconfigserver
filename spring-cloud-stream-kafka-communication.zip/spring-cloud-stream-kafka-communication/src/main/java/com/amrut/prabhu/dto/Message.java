package com.amrut.prabhu.dto;

public record Message(String name) {
}
